# 30분마다 매수하겠다
# */30 * * * * 


import pyupbit
import pandas as pd

access = "17iEMcWV2GQRJlAcmxri0cxoLxmrGjmKjbq4IhK8"          # 본인 값으로 변경
secret = "RxQApejEyEIxorrqtfEcoLCw9BGPeL46HFuGVxg2"          # 본인 값으로 변경
upbit = pyupbit.Upbit(access, secret)                        # upbit는 객체


# RSI지표 수치를 구해준다. 첫번째: 분봉/일봉 정보, 두번째: 기간
# 정해진 숫자기간동안에서 전일대비 상승분의 평균/(전일대비 상승분의 평균+하락분의 평균)
def GetRSI(ohlcv,period):
    ohlcv["close"] = ohlcv["close"]
    delta = ohlcv["close"].diff()
    up, down = delta.copy(), delta.copy()
    up[up < 0] = 0
    down[down > 0] = 0
    _gain = up.ewm(com=(period - 1), min_periods=period).mean()
    _loss = down.abs().ewm(com=(period - 1), min_periods=period).mean()
    RS = _gain / _loss
    return pd.Series(100 - (100 / (1 + RS)), name="RSI")


# 비트코인의 240분봉(캔들) 정보를 가져온다
df = pyupbit.get_ohlcv("KRW-BTC", interval="minute240")

# 오늘(현재)rsi
rsi14=float(GetRSI(df, 14).iloc[-1])
print("==================================")
print("BTC_BOT_WORKING!!")
print("NOW-RSI: ", rsi14)
print("==================================")
print()
#RSI지표가 30이하라면
if rsi14 <=30:
    #비트코인을 5천원씩 시장가로 매수합니다!
    print("구매 성공!")
    print(upbit.buy_market_order("KRW-BTC",5000))
else:
    print("구매 실패!")
    print("rsi > 30")


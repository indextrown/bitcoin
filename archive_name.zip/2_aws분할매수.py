import pyupbit


access = "17iEMcWV2GQRJlAcmxri0cxoLxmrGjmKjbq4IhK8"          # 본인 값으로 변경
secret = "RxQApejEyEIxorrqtfEcoLCw9BGPeL46HFuGVxg2"          # 본인 값으로 변경
upbit = pyupbit.Upbit(access, secret)                        # upbit는 객체


upbit.buy_market_order("KRW-BTC", 5000)   
import pyupbit
import time
import pandas as pd
import requests


#챕터7까지 진행하시면서 봇은 점차 완성이 되어 갑니다!!!
#챕터5까지 완강 후 봇을 돌리셔도 되지만 이왕이면 7까지 완강하신 후 돌리시는 걸 추천드려요!

access = "A0X27AGgl8UYAC2cFMYzyrMlfxn1DsgrxoGjLVc2"          # 본인 값으로 변경
secret = "JkaADmlhsKOAcOlSsYw1WJ7DIpSnM9gGzP7dLRBx"          # 본인 값으로 변경

#업비트 객체를 만들어요 액세스 키와 시크릿 키를 넣어서요.
upbit = pyupbit.Upbit(access, secret)


def get_balance_info(access_key, secret_key):
    # 업비트 객체 생성
    upbit = pyupbit.Upbit(access_key, secret_key)
    
    # 보유 중인 모든 암호화폐의 잔고 및 단가 정보
    my_balances = upbit.get_balances()
    print("내 잔고")
    # 보유 현금 조회
    print("현금: ", upbit.get_balance("KRW"))
    for coin_balance in my_balances:
        # 코인이름(티커)
        ticker = coin_balance['currency']
        
        # 해당하는 티커 무시
        if ticker in ["KRW", "APENFT"]:
            continue
        
        # 마켓에서 거래되고 있는 코인 현재가격
        now_price = pyupbit.get_current_price("KRW-" + ticker)
        print(ticker, "보유잔고: ", coin_balance['balance'])
        print("평균매입단가|현재마켓거래가: ", coin_balance['avg_buy_price'], "|", now_price)
        
        # 매수평균가
        avg_price = float(coin_balance['avg_buy_price'])
        
        # 수익률 = (현재가격 - 매수평균가) / 매수평균가 * 100.0 
        revenu_rate = (now_price - avg_price) / avg_price * 100.0
        print("수익률: ", revenu_rate, "%") 
        print()
        print()

def get_balance_info_return(access_key, secret_key):
    # 업비트 객체 생성
    upbit = pyupbit.Upbit(access_key, secret_key)
    
    # 보유 중인 모든 암호화폐의 잔고 및 단가 정보
    my_balances = upbit.get_balances()
    balance_info = []

    for coin_balance in my_balances:
        # 코인이름(티커)
        ticker = coin_balance['currency']
        
        # 해당하는 티커 무시
        if ticker in ["KRW", "APENFT"]:
            continue
        
        # 마켓에서 거래되고 있는 코인 현재가격
        now_price = pyupbit.get_current_price("KRW-" + ticker)
        coin_info = {
            'ticker': ticker,
            'balance': coin_balance['balance'],
            'avg_buy_price': coin_balance['avg_buy_price'],
            'current_price': now_price
        }
        
        # 매수평균가
        avg_price = float(coin_balance['avg_buy_price'])
        
        # 수익률 = (현재가격 - 매수평균가) / 매수평균가 * 100.0 
        revenu_rate = (now_price - avg_price) / avg_price * 100.0
        coin_info['revenu_rate'] = revenu_rate
        balance_info.append(coin_info)

    return balance_info




# RSI지표 수치를 구해준다. 첫번째: 분봉/일봉 정보, 두번째: 기간
# 정해진 숫자기간동안에서 전일대비 상승분의 평균/(전일대비 상승분의 평균+하락분의 평균)
def GetRSI(ohlcv,period):
    ohlcv["close"] = ohlcv["close"]
    delta = ohlcv["close"].diff()
    up, down = delta.copy(), delta.copy()
    up[up < 0] = 0
    down[down > 0] = 0
    _gain = up.ewm(com=(period - 1), min_periods=period).mean()
    _loss = down.abs().ewm(com=(period - 1), min_periods=period).mean()
    RS = _gain / _loss
    return pd.Series(100 - (100 / (1 + RS)), name="RSI")

# 업비트 API 접근 정보
access = "17iEMcWV2GQRJlAcmxri0cxoLxmrGjmKjbq4IhK8"  # 본인 값으로 변경
secret = "RxQApejEyEIxorrqtfEcoLCw9BGPeL46HFuGVxg2"  # 본인 값으로 변경




def send_slack_message(token, channel, text):
    """
    Slack 메시지를 보내는 함수

    Args:
        token (str): Slack API 토큰
        channel (str): 메시지를 보낼 채널 이름 (예: "#srtauto매매")
        text (str): 전송할 메시지 텍스트
    """
    response = requests.post(
        "https://slack.com/api/chat.postMessage",
        headers={"Authorization": "Bearer " + token},
        data={"channel": channel, "text": text}
    )

    if response.status_code == 200:
        print("Slack 메시지 전송 성공")
    else:
        print("Slack 메시지 전송 실패")


# 30분마다 매수하겠다
# */30 * * * * 

# 30분, 240(4시간마다 바뀜)분봉 기준
# 예를들어 4~8시 사이 rsi지표가 30 이하라면
# 4시간 동안은 항상 30이하일거다/ 실시간으로 변화는 값 보면(iloc[-1]) 30이하 아닐수도
# 즉 8번 기회 실행이 됨

import pyupbit
import pandas as pd
from upbit_module import send_slack_message
from upbit_module import get_balance_info_return

# Slack API 토큰
token = "xoxb-5635998021173-5636061047029-UPemRFwqW11nYtMfAO41qHst"
# 채널 및 메시지 텍스트
channel = "#srtauto매매"


# upbit token
access = "17iEMcWV2GQRJlAcmxri0cxoLxmrGjmKjbq4IhK8"          # 본인 값으로 변경
secret = "RxQApejEyEIxorrqtfEcoLCw9BGPeL46HFuGVxg2"          # 본인 값으로 변경
upbit = pyupbit.Upbit(access, secret)                        # upbit는 객체



# 메시지 리스트 생성
messages = [
    "==============================\n",
    "현재 잔고 보고서\n",
]
# 보유 현금 조회
money = upbit.get_balance("KRW")
messages.append("\n현금: "+ str(money)+"\n")
# 잔고 정보 가져오기
balances = get_balance_info_return(access, secret)  
for coin_info in balances:
    ticker = coin_info['ticker']
    now_price = pyupbit.get_current_price("KRW-" + ticker)
    print(now_price)
    print()
    print()
    print()

    # 매수평균가
    avg_price = float(coin_info['avg_buy_price'])
    revenu_rate = (now_price - avg_price) / avg_price * 100.0

    text_1 = f"코인: {ticker}\n잔고: {coin_info['balance']}\n수익률: {revenu_rate}\n"
    text_2 = f"평균매입단가|현재마켓거래가:\n{coin_info['avg_buy_price']}|{now_price}\n"
    
    # 메시지 리스트에 추가
    
    messages.append(text_1)
    messages.append(text_2+"\n")

messages.append("==============================")

# 함수 호출 (한 번의 호출로 메시지 리스트 보내기)
send_slack_message(token, channel, "".join(messages))





# RSI지표 수치를 구해준다. 첫번째: 분봉/일봉 정보, 두번째: 기간
# 정해진 숫자기간동안에서 전일대비 상승분의 평균/(전일대비 상승분의 평균+하락분의 평균)
def GetRSI(ohlcv,period):
    ohlcv["close"] = ohlcv["close"]
    delta = ohlcv["close"].diff()
    up, down = delta.copy(), delta.copy()
    up[up < 0] = 0
    down[down > 0] = 0
    _gain = up.ewm(com=(period - 1), min_periods=period).mean()
    _loss = down.abs().ewm(com=(period - 1), min_periods=period).mean()
    RS = _gain / _loss
    return pd.Series(100 - (100 / (1 + RS)), name="RSI")


# 비트코인의 240분봉(캔들) 정보를 가져온다
df = pyupbit.get_ohlcv("KRW-BTC", interval="minute240")

# 오늘(현재)rsi
rsi14=float(GetRSI(df, 14).iloc[-1])
print("==================================")
print("하루동안 8번 기회 있습니다")
print("BTC_BOT_WORKING!!")
print("NOW-RSI: ", rsi14)
print("==================================")
print()
# 함수 호출



#RSI지표가 30이하라면
if rsi14 <=30:
    #비트코인을 5천원씩 시장가로 매수합니다!
    print("구매 성공!")
    print(upbit.buy_market_order("KRW-BTC",5000))
    text_1 = "구매 성공!"
    text_2 = "축하합니다!"

    # 함수 호출
    send_slack_message(token, channel, text_1)
    send_slack_message(token, channel, text_2)
else:
    print("구매 실패!")
    print("rsi > 30")
    text_1= "구매 실패!"

    # 함수 호출
    send_slack_message(token, channel, text_1)







    
